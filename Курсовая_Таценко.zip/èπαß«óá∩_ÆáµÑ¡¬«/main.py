import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog, QMessageBox,QLineEdit, \
QFileDialog, QLabel,  QVBoxLayout, QStyledItemDelegate, QTableWidget, QTableWidgetItem
from PyQt5.QtGui import QStandardItemModel, QStandardItem, QPixmap
from PyQt5.QtCore import pyqtSignal, Qt, QSize
from datetime import datetime, timedelta
from PyQt5 import uic
import sqlite3

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('VhodF.ui', self)
        self.registration_window = RegistWindow(self)
        self.admin_window = AdminWindow(self)
        self.user_window = UserWindow(self)
        self.Button_regis.clicked.connect(self.registration_window.show)
        self.Button_enter.clicked.connect(self.check_login_and_show_window)
        self.lineEdit_pass.setEchoMode(QLineEdit.Password)

    def check_login_and_show_window(self):
        '''Получаем данные из lineEdit'''
        логин = self.lineEdit_login.text()
        пароль = self.lineEdit_pass.text()

        try:
            '''Проверка на пустые поля'''
            if not логин or not пароль:
                QMessageBox.warning(self, 'Предупреждение', 'Пожалуйста, заполните все поля.')
                return

            '''Проверка логина и пароля в таблице клиентов'''
            query_user = "SELECT * FROM клиенты WHERE имя = ? AND пароль = ?"
            self.registration_window.cursor.execute(query_user, (логин, пароль))
            result_user = self.registration_window.cursor.fetchone()

            '''Проверка логина и пароля в таблице руководства'''
            query_admin = "SELECT * FROM Руководство WHERE логин = ? AND пароль = ?"
            self.registration_window.cursor.execute(query_admin, (логин, пароль))
            result_admin = self.registration_window.cursor.fetchone()

            if result_user:
                QMessageBox.information(self, 'Успех', 'Вход пользователя выполнен успешно.')
                self.user_window.show()
            elif result_admin:
                QMessageBox.information(self, 'Успех', 'Вход администратора выполнен успешно.')
                self.admin_window.show()
            else:
                QMessageBox.warning(self, 'Ошибка', 'Неверный логин или пароль.')

        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Ошибка при выполнении запроса: {str(e)}')

class ImageDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        '''Получаем данные из модели'''
        data = index.data(Qt.DisplayRole)

        '''Убеждаемся, что данные не пусты'''
        if data:
            '''Извлекаем текст и фотографии из форматированной строки'''
            text, photo_data = data.split('\n', 1)

            '''Рисуем часть с текстом'''
            option.displayAlignment = Qt.AlignTop | Qt.AlignLeft
            super().paint(painter, option, index)

            '''Рисуем часть с фотографией'''
            pixmap = QPixmap()
            pixmap.loadFromData(photo_data.encode())
            photo_rect = option.rect.adjusted(0, 0, 0, 0)
            painter.drawPixmap(photo_rect, pixmap)

    def sizeHint(self, option, index):
        '''Регулируем размер элемента, чтобы вместить фотографию'''
        size = super().sizeHint(option, index)
        size.setHeight(size.height() + size.width() // 3)
        return size

class UserWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('User.ui', self)
        self.button_exit.clicked.connect(self.close)
        self.Kab_window = KabWindow(self)
        '''Инициализация модели для списка'''
        self.model = QStandardItemModel(self)
        self.listView.setModel(self.model)
        self.akkaunt.clicked.connect(self.Kab_window.show)

        '''Загрузка данных из базы данных и отображение их в listView'''
        self.load_data_from_database()

        self.button_search.clicked.connect(self.search_data)
        self.button_buy.clicked.connect(self.make_order)

        self.delegate = ImageDelegate(self.listView)
        self.listView.setItemDelegate(self.delegate)

        self.listView.clicked.connect(self.show_item_details)
        self.button_plus.clicked.connect(self.increment_quantity)
        self.button_minus.clicked.connect(self.decrement_quantity)

    def increment_quantity(self):
        # Получение текущего значения из lineEdit_kolvo
        current_value = int(self.lineEdit_kolvo.text()) if self.lineEdit_kolvo.text().isdigit() else 0
        # Увеличение значения на 1
        new_value = current_value + 1
        # Обновление значения в lineEdit_kolvo
        self.lineEdit_kolvo.setText(str(new_value))

    def decrement_quantity(self):
        # Получение текущего значения из lineEdit_kolvo
        current_value = int(self.lineEdit_kolvo.text()) if self.lineEdit_kolvo.text().isdigit() else 0
        # Уменьшение значения на 1, но не менее 1
        new_value = max(current_value - 1, 1)
        # Обновление значения в lineEdit_kolvo
        self.lineEdit_kolvo.setText(str(new_value))

    def load_data_from_database(self):
        try:
            '''Подключение к базе данных'''
            db_connection = sqlite3.connect('Jewelry.db')
            cursor = db_connection.cursor()

            '''Выполнение SQL-запроса для выборки конкретных полей из таблицы "ювелирные_изделия"'''
            cursor.execute("SELECT id, название, цена, размер, материал, фото FROM ювелирные_изделия")
            data = cursor.fetchall()

            '''Очищаем содержимое'''
            self.model.clear()

            '''Заполняем данными'''
            for row_data in data:
                formatted_data = f"{row_data[1]}\nЦена: {row_data[2]}\nРазмер: {row_data[3]}\nМатериал: {row_data[4]}"
                item = QStandardItem(formatted_data)
                item.setData(row_data[5], Qt.UserRole)
                self.model.appendRow(item)

        except sqlite3.Error as e:
            print(f'Ошибка при загрузке данных из базы данных: {str(e)}')
        finally:
            '''Закрываем соединение с базой данных'''
            if db_connection:
                db_connection.close()

    def search_data(self):
        try:
            '''Подключение к базе данных'''
            db_connection = sqlite3.connect('Jewelry.db')
            cursor = db_connection.cursor()

            '''Получение текста для поиска из QLineEdit'''
            search_text = self.lineEdit.text()

            '''Выполнение SQL-запроса для поиска'''
            cursor.execute("SELECT id, название, цена, размер, материал, фото FROM ювелирные_изделия WHERE название LIKE ?", (f"%{search_text}%",))
            data = cursor.fetchall()

            '''Очищаем содержимое '''
            self.model.clear()

            '''Заполняем данными'''
            for row_data in data:
                formatted_data = f"{row_data[1]}\nЦена: {row_data[2]}\nРазмер: {row_data[3]}\nМатериал: {row_data[4]}"
                item = QStandardItem(formatted_data)
                item.setData(row_data[5], Qt.UserRole)
                self.model.appendRow(item)

        except sqlite3.Error as e:
            print(f'Ошибка при поиске данных в базе данных: {str(e)}')
        finally:
            '''Закрываем соединение с базой данных'''
            if db_connection:
                db_connection.close()

    def make_order(self):
        try:
            '''Проверка, выбран ли элемент в listView'''
            selected_indexes = self.listView.selectedIndexes()
            if not selected_indexes:
                QMessageBox.warning(self, 'Ошибка', 'Выберите товар для заказа.')
                return

            '''Получение выбранного элемента из listView'''
            selected_index = selected_indexes[0]
            selected_data = selected_index.data().split('\n')

            '''Получение текущего имени клиента из MainWindow'''
            client_name = self.parent().lineEdit_login.text()

            '''Получение названия выбранного товара и его цены из базы данных'''
            jewelry_name = selected_data[0]
            jewelry_price = self.get_jewelry_price(jewelry_name)

            '''Получение текущей даты'''
            current_date = datetime.now().strftime('%d.%m.%Y')

            '''Вычисление даты доставки (через 7 дней от текущей даты)'''
            delivery_date = (datetime.now() + timedelta(days=7)).strftime('%d.%m.%Y')

            '''Получение количества товаров из lineEdit_kolvo'''
            quantity_str = self.lineEdit_kolvo.text()
            quantity = int(quantity_str) if quantity_str.isdigit() else 1  # По умолчанию 1, если введено не число

            delivery_cost = 500  # Примерная стоимость доставки
            total_price = quantity * int(jewelry_price) + delivery_cost  # Общая стоимость

            '''Подключение к базе данных'''
            db_connection = sqlite3.connect('Jewelry.db')
            cursor = db_connection.cursor()

            try:
                '''Выполнение запроса для добавления данных о доставке в таблицу доставка'''
                cursor.execute(
                    "INSERT INTO доставка (дата_доставки, стоимость_доставки, название_товара, цена_товара, количество_товаров, общая_сумма) VALUES (?, ?, ?, ?, ?, ?)",
                    (delivery_date, delivery_cost, jewelry_name, jewelry_price, quantity, total_price))

                '''Выполнение запроса для добавления заказа в базу данных'''
                cursor.execute(
                    "INSERT INTO заказы (имя_клиента, ювелирное_изделие, дата_заказа, дата_доставки, цена_товара, количество_товаров) VALUES (?, ?, ?, ?, ?, ?)",
                    (client_name, jewelry_name, current_date, delivery_date, jewelry_price, quantity))

                db_connection.commit()

                '''Обновление данных в личном кабинете'''
                self.Kab_window.update_order_details(delivery_date, jewelry_price, quantity)

            except sqlite3.Error as e:
                print(f'Ошибка при выполнении запроса: {str(e)}')
                QMessageBox.warning(self, 'Ошибка', f'Ошибка при выполнении запроса: {str(e)}')

            finally:
                '''Закрываем соединение с базой данных'''
                db_connection.close()

        except Exception as ex:
            print(f'Произошла ошибка: {str(ex)}')
            QMessageBox.warning(self, 'Ошибка', f'Произошла ошибка: {str(ex)}')

    def get_jewelry_price(self, jewelry_name):
        '''Получение цены товара из базы данных по его названию'''
        db_connection = sqlite3.connect('Jewelry.db')
        cursor = db_connection.cursor()

        try:
            cursor.execute("SELECT цена FROM ювелирные_изделия WHERE название = ?", (jewelry_name,))
            price = cursor.fetchone()[0]
            return price
        except sqlite3.Error as e:
            print(f'Ошибка при получении цены из базы данных: {str(e)}')
            return 0
        finally:
            db_connection.close()

    def show_item_details(self, index):
        '''Отображение фотографии'''
        photo_data = index.data(Qt.UserRole)
        if photo_data:
            item_details_dialog = ItemDetailsDialog(photo_data, self)
            item_details_dialog.exec_()

class ItemDetailsDialog(QDialog):
    def __init__(self, photo_data, parent=None):
        super().__init__(parent)

        '''Отобразить фото в QLabel'''
        label = QLabel(self)
        pixmap = QPixmap()
        pixmap.loadFromData(photo_data)
        label.setPixmap(pixmap.scaledToWidth(512))

        '''Создать макет и добавить QLabel'''
        layout = QVBoxLayout(self)
        layout.addWidget(label)

        '''Настроить размеры окна'''
        self.setFixedSize(QSize(512, 512))
        self.setWindowTitle('Фото товара')

class KabWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('kab.ui', self)
        self.button_exit.clicked.connect(self.close)

        # Найдите ваш QTableWidget
        self.tableWidget = self.findChild(QTableWidget, 'tableWidget')

        # Установите заголовки столбцов
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(
            ['Количество', 'Цена украшения', 'Дата доставки', 'Цена доставки', 'Итого'])

    def update_order_details(self, delivery_date, jewelry_price, quantity):
        # Рассчитайте стоимость доставки и общую сумму (примерный расчет, возможно, нужно скорректировать)
        delivery_cost = 100  # Примерная стоимость доставки
        total_price = jewelry_price * quantity + delivery_cost

        # Добавьте новую строку в таблицу
        row_position = self.tableWidget.rowCount()
        self.tableWidget.insertRow(row_position)

        # Установите значения в ячейки таблицы
        self.tableWidget.setItem(row_position, 0, QTableWidgetItem(str(quantity)))
        self.tableWidget.setItem(row_position, 1, QTableWidgetItem(str(jewelry_price)))
        self.tableWidget.setItem(row_position, 2, QTableWidgetItem(delivery_date))
        self.tableWidget.setItem(row_position, 3, QTableWidgetItem(str(delivery_cost)))
        self.tableWidget.setItem(row_position, 4, QTableWidgetItem(str(total_price)))

class RegistWindow(QDialog):
    data_added = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('RegisF.ui', self)

        '''Создаем соединение с базой данных'''
        self.conn = sqlite3.connect('Jewelry.db')
        self.cursor = self.conn.cursor()

        '''Подключаем обработчик кнопки'''
        self.button_vhod.clicked.connect(self.save_data_and_emit_signal)

    def save_data_and_emit_signal(self):
        '''Получаем данные из lineEdit'''
        имя = self.lineEdit_1.text()
        фамилия = self.lineEdit_2.text()
        телефон = self.lineEdit_3.text()
        адрес = self.lineEdit_4.text()
        пароль = self.lineEdit_5.text()

        '''Проверяем, что все поля заполнены'''
        if not имя or not фамилия or not телефон or not пароль:
            QMessageBox.warning(self, 'Предупреждение', 'Пожалуйста, заполните все поля.')
            return

        try:
            '''Проверяем, существует ли пользователь с таким именем'''
            query_check_user = "SELECT * FROM клиенты WHERE имя = ?"
            self.cursor.execute(query_check_user, (имя,))
            existing_user = self.cursor.fetchone()

            if existing_user:
                QMessageBox.warning(self, 'Ошибка', 'Пользователь с таким именем уже существует.')
                return

            '''Выполняем SQL-запрос для добавления данных в таблицу "клиенты"'''
            query = "INSERT INTO клиенты (имя, фамилия, телефон, адрес, пароль) VALUES (?, ?, ?, ?, ?)"
            self.cursor.execute(query, (имя, фамилия, телефон, адрес, пароль))
            self.conn.commit()

            QMessageBox.information(self, 'Успех', 'Регистрация прошла успешно !')

            '''Отправляем сигнал об успешном добавлении данных'''
            self.data_added.emit()
        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось добавить данные: {str(e)}')

    def closeEvent(self, event):
        event.accept()

class AdminWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('AdminF.ui', self)
        self.mini_window = MiniWindow(self, self.load_table_data)
        self.miniredach_window = MiniredachWindow(self)
        '''Создаем экземпляр NewAdmin окна'''
        self.new_admin_window = NewAdmin(self)
        self.Button_dob.clicked.connect(self.show_selected_tab_window)
        self.Button_izmen.clicked.connect(self.miniredach_window.show)
        self.Button_del.clicked.connect(self.delete_selected_row)
        self.Button_exit.clicked.connect(self.close)

        '''Создаем соединение с базой данных'''
        self.conn = sqlite3.connect('Jewelry.db')
        self.cursor = self.conn.cursor()

        self.model = QStandardItemModel(self)
        self.tableView.setModel(self.model)

        self.load_table_names()
        self.comboBox.currentIndexChanged.connect(self.load_table_data)

        '''Создаем и заполняем таблицы, если их нет'''
        self.create_and_fill_jewelry_table()

        self.Button_dob.clicked.connect(self.show_new_admin_window)
        self.Button_foto.clicked.connect(self.choose_and_insert_photo)

        '''Обновляем tableView после создания и заполнения таблиц'''
        self.load_table_data()

        self.update_button_activity()
        self.comboBox.currentIndexChanged.connect(self.update_button_activity)

        self.new_admin_window.data_added.connect(self.load_table_data)
        self.new_admin_window.data_deleted.connect(self.load_table_data)
        self.miniredach_window.data_updated.connect(self.load_table_data)
        self.regist_window = RegistWindow(self)
        self.regist_window.data_added.connect(self.load_table_data)

    def choose_and_insert_photo(self):
        '''Получаем текущую выбранную строку'''
        selected_indexes = self.tableView.selectedIndexes()

        if not selected_indexes:
            QMessageBox.warning(self, 'Ошибка', 'Выберите строку для добавления фотографии.')
            return

        '''Получаем id из первой ячейки выбранной строки'''
        selected_id = selected_indexes[0].sibling(selected_indexes[0].row(), 0).data()

        initial_path = 'фото'

        file_dialog = QFileDialog()
        file_dialog.setDirectory(initial_path)
        file_dialog.setNameFilter("Images (*.png *.xpm *.jpg *.bmp)")
        file_path, _ = file_dialog.getOpenFileName(self, "Выберите изображение", "", "Images (*.png *.xpm *.jpg *.bmp)")

        '''Проверяем, был ли выбран файл'''
        if file_path:

            with open(file_path, 'rb') as file:
                photo_data = file.read()

            '''Обновляем запись в базе данных с выбранным id'''
            current_tab = self.comboBox.currentText()
            if current_tab == "ювелирные_изделия":
                self.cursor.execute(f"UPDATE {current_tab} SET фото = ? WHERE id = ?", (photo_data, selected_id))
                self.conn.commit()

                '''Обновляем tableView после добавления фотографии'''
                self.load_table_data()

    def show_selected_tab_window(self):
        current_tab = self.comboBox.currentText()
        print(f"Current tab: {current_tab}")

        '''Открываем соответствующее окно в зависимости от выбранной вкладки'''
        if current_tab == "ювелирные_изделия":
            print("Opening MiniWindow")
            self.mini_window.show()
        elif current_tab == "Руководство":
            print("Opening NewAdminWindow")
            self.new_admin_window.show()
        else:
            print("Unexpected tab:", current_tab)

    def show_new_admin_window(self):
        if self.comboBox.currentText() == "Руководство":
            self.new_admin_window.show()
        elif self.comboBox.currentText() == "ювелирные_изделия":
            self.mini_window.show()

    def update_button_activity(self):
        '''Делаем кнопку добавить активной только на вкладках "Ювелирные_изделия" и "Руководство"'''
        current_tab = self.comboBox.currentText()
        self.Button_dob.setEnabled(current_tab in ["ювелирные_изделия", "Руководство"])
        self.Button_izmen.setEnabled(current_tab in ["ювелирные_изделия"])
    def delete_selected_row(self):
        selected_indexes = self.tableView.selectedIndexes()

        if selected_indexes:
            '''Получаем id из первой ячейки выбранной строки'''
            selected_id = selected_indexes[0].sibling(selected_indexes[0].row(), 0).data()

            '''Удаляем строку из базы данных'''
            current_tab = self.comboBox.currentText()

            if current_tab == "Руководство":
                self.new_admin_window.delete_admin(selected_id)
            else:
                self.cursor.execute(f"DELETE FROM {current_tab} WHERE id = ?", (selected_id,))
                self.conn.commit()

                '''Обновляем tableView после удаления строки'''
                self.load_table_data()

    def load_table_names(self):
        '''Получаем список названий таблиц в базе данных'''
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        table_names = self.cursor.fetchall()

        '''Очищаем содержимое comboBox'''
        self.comboBox.clear()

        '''Заполняем comboBox названиями таблиц'''
        for name in table_names:
            self.comboBox.addItem(name[0])

    def load_table_data(self):
        table_name = self.comboBox.currentText()

        '''Ввыборки данных из таблицы'''
        self.cursor.execute(f"SELECT * FROM {table_name}")
        data = self.cursor.fetchall()
        self.model.clear()

        header_labels = [description[0] for description in self.cursor.description]
        self.model.setHorizontalHeaderLabels(header_labels)

        for row_num, row_data in enumerate(data):
            items = [QStandardItem(str(col_data)) for col_data in row_data]
            self.model.appendRow(items)

        self.tableView.verticalHeader().setHidden(True)

    def closeEvent(self, event):
        '''Закрываем соединение с базой данных при закрытии окна'''
        self.conn.close()
        event.accept()

    def create_and_fill_jewelry_table(self):
        '''скрипт для создания таблицы ювелирные_изделия '''
        self.cursor.execute('''
                  CREATE TABLE IF NOT EXISTS ювелирные_изделия (
                      id INTEGER PRIMARY KEY,
                      название TEXT,
                      цена DECIMAL(10, 2),
                      размер DECIMAL(6, 2),
                      материал TEXT,
                      фото BLOB
                  );
                  ''')

        self.cursor.execute('''
                  CREATE TABLE IF NOT EXISTS доставка (
                      id INTEGER PRIMARY KEY,
                      дата_доставки TEXT,
                      стоимость_доставки DECIMAL(8, 2),
                      название_товара VARCHAR(50),
                      цена_товара DECIMAL(10, 2),
                      количество_товаров INTEGER,
                      общая_сумма FLOAT
                  );
                  ''')

        self.cursor.execute('''
                  CREATE TABLE IF NOT EXISTS клиенты (
                      id INTEGER PRIMARY KEY,
                      имя TEXT,
                      фамилия TEXT,
                      телефон TEXT,
                      адрес TEXT,
                      пароль TEXT
                  );
                  ''')
        self.cursor.execute('''
                  CREATE TABLE IF NOT EXISTS заказы (
                      id INTEGER PRIMARY KEY,
                      имя_клиента INTEGER,
                      ювелирное_изделие INTEGER,
                      дата_заказа DATE,
                      дата_доставки DATE,
                      цена_товара DECIMAL(10, 2),
                      количество_товаров INTEGER,
                      FOREIGN KEY (имя_клиента) REFERENCES клиенты(id),
                      FOREIGN KEY (ювелирное_изделие) REFERENCES ювелирные_изделия(id)
                  );
                  ''')
        self.cursor.execute('''
                  CREATE TABLE IF NOT EXISTS Руководство ( 
                      id_администратора INTEGER PRIMARY KEY, 
                      логин TEXT NOT NULL, 
                      пароль TEXT NOT NULL 
                  ); 
                  ''')
        '''Фиксируем изменения'''
        self.conn.commit()
        self.miniredach_window.data_updated.connect(self.load_table_data)

class MiniWindow(QDialog):
    def __init__(self, parent=None, update_function=None):
        super().__init__(parent)
        uic.loadUi('mini.ui', self)
        self.update_function = update_function
        self.pushButton.clicked.connect(self.save_data)

    def save_data(self):
        '''Получаем данные из lineEdit'''
        название = self.lineEdit.text()
        цена = self.lineEdit_2.text()
        размер = self.lineEdit_3.text()
        материал = self.lineEdit_4.text()

        '''запрос для добавления данных в таблицу'''
        query = f"INSERT INTO ювелирные_изделия (название, цена, размер, материал) VALUES (?, ?, ?, ?)"
        self.parent().cursor.execute(query, (название, цена, размер, материал))
        self.parent().conn.commit()

        '''Обновляем данные в AdminWindow'''
        if self.update_function:
            self.update_function()

        self.close()

class MiniredachWindow(QDialog):
    data_updated = pyqtSignal()
    def __init__(self, parent=None, update_function=None):
        super().__init__(parent)
        uic.loadUi('mini_izmen.ui', self)
        self.update_function = update_function

        '''Подключаем кнопку изменения к функции'''
        self.button_s.clicked.connect(self.update_data)

    def update_data(self):
        '''Получаем данные из lineEdit'''
        id_value = self.lineEdit.text()
        column_name = self.lineEdit_2.text()
        new_value = self.lineEdit_3.text()

        '''Выполняем запрос для обновления данных'''
        try:
            self.parent().cursor.execute(
                f"UPDATE {self.parent().comboBox.currentText()} SET {column_name} = ? WHERE id = ?",
                (new_value, id_value))
            self.parent().conn.commit()
            QMessageBox.information(self, 'Успех', 'Данные успешно обновлены')
            self.data_updated.emit()
        except Exception as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось обновить данные: {str(e)}')
    def closeEvent(self, event):
        event.accept()

class NewAdmin(QDialog):
    data_added = pyqtSignal()
    data_deleted = pyqtSignal()
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('NewAdmin.ui', self)
        '''Подключаем обработчики кнопок'''
        self.button_newadd.clicked.connect(self.add_new_admin)

    def delete_admin(self, admin_id):
        '''соединение с базой данных'''
        conn = sqlite3.connect('Jewelry.db')
        cursor = conn.cursor()

        try:
            '''Выполняем запрос для удаления данных из таблицы'''
            cursor.execute('''
                DELETE FROM Руководство WHERE id_администратора = ?
            ''', (admin_id,))

            '''Фиксируем изменения'''
            conn.commit()

            self.data_added.emit()

            QMessageBox.information(self, 'Информация', 'Данные успешно удалены из таблицы "Руководство".')
        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось удалить данные: {str(e)}')
        finally:
            '''Закрываем соединение с базой данных'''
            conn.close()
    def add_new_admin(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        '''Проверяем, что логин и пароль не пустые'''
        if not login or not password:
            QMessageBox.warning(self, 'Предупреждение', 'Логин и пароль не могут быть пустыми.')
            return
        '''Создаем соединение с базой данных'''
        conn = sqlite3.connect('Jewelry.db')
        cursor = conn.cursor()
        try:
            '''Выполняем запрос для вставки данных в таблицу "Руководство"'''
            cursor.execute('''
                INSERT INTO Руководство (логин, пароль) VALUES (?, ?)
            ''', (login, password))

            '''Фиксируем изменения'''
            conn.commit()
            self.data_added.emit()
            QMessageBox.information(self, 'Информация', 'Данные успешно добавлены в таблицу "Руководство".')
        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось добавить данные: {str(e)}')
        finally:
            '''Закрываем соединение с базой данных'''
            conn.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())